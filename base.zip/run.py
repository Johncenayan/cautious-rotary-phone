import os
os.system('python app.py;while :; do python app.py; sleep 1s; done')
